# Smallest N
- birth_year_all.png - 10
- kreatinine_distr.png - 5
- kreatinine_distr_sex.png - 5
- ldl_distr.png - 60 
- ldl_distr_sex.png - 60
- measure_count_all.png - 6
- measure_years_100K.png - 239,313
- sex_all.png - 23,271
- value_name_table.png - 6